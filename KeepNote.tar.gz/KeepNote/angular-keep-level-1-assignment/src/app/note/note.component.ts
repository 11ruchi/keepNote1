import { Component, OnInit } from '@angular/core';
import { Note } from 'src/app/note/note';
import { NoteService } from 'src/app/note.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {

public note : Note;
public noteList : Note[];

 
  //public title : string;
  //public description : string;
  constructor(private noteService : NoteService) { 
    this.note = new Note();
    this.noteList= [];
  }

  ngOnInit() {
    this.noteService.getNotes().subscribe(
      data => this.noteList = data,
      err => console.log(err)
      

    )
  }

  addNote(){
    this.noteList.push(this.note);
    this.noteService.addNote(this.note).subscribe(
      data => {},
      err => {console.log(err)
      }
      );
    console.log(this.noteList);
    this.note = new Note;
    //console.log(this.title +" "+ this.description);
    
  }
}
